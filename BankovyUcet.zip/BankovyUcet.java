
    public class BankovyUcet {
        private String menoMajitela;
        private String cisloUctu;
        private double zostatok;

        public BankovyUcet(String menoMajitela, String cisloUctu) {
            this.menoMajitela = menoMajitela;
            this.cisloUctu = cisloUctu;
            this.zostatok = 0.0;
        }

        public String getMenoMajitela() {
            return menoMajitela;
        }

        public String getCisloUctu() {
            return cisloUctu;
        }

        public double getZostatok() {
            return zostatok;
        }

        public void vklad(double suma) {
            zostatok += suma;
            System.out.println("Vklad " + suma + " € uskutočnený. Nový zostatok je " + zostatok + " €");
        }

        public void vyber(double suma) {
            if (suma <= zostatok) {
                zostatok -= suma;
                System.out.println("Výber " + suma + " € uskutočnený. Nový zostatok je " + zostatok + " €");
            } else {
                System.out.println("Nedostatočný zostatok na účte.");
            }
        }

        public void infoOUcte() {
            System.out.println("Majiteľ účtu: " + menoMajitela);
            System.out.println("Číslo účtu: " + cisloUctu);
            System.out.println("Zostatok: " + zostatok + " €");
        }

        public static void main(String[] args) {
            BankovyUcet ucet = new BankovyUcet("John Doe", "123456789");

            ucet.vklad(1000.0);
            ucet.vyber(500.0);
            ucet.infoOUcte();
        }
    }

